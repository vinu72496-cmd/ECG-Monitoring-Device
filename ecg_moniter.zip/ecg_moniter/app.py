import asyncio
import serial
import json
import numpy as np
import time

# --- CONFIGURATION ---
# Your hardware port is confirmed as COM3
SERIAL_PORT = 'COM3' 
BAUD_RATE = 115200

# Connected clients pool for the Web Dashboard
CONNECTED_CLIENTS = set()

# Global variables for peak detection & BPM estimation
samples = []
timestamps = []
bpm = 72  # Default starting placeholder
SAMPLING_RATE = 100  # 100 Hz based on ESP32 delay
MAX_SAMPLES = 500    # Window size to analyze peaks (~5 seconds of data)

def estimate_bpm(value):
    """
    Implements a basic peak-detection algorithm to count heartbeats 
    and estimate BPM dynamically.
    """
    global samples, timestamps, bpm
    
    current_time = time.time()
    samples.append(value)
    timestamps.append(current_time)
    
    # Maintain a moving window of recent data points
    if len(samples) > MAX_SAMPLES:
        samples.pop(0)
        timestamps.pop(0)
        
    if len(samples) < 200:
        return bpm # Wait for enough data points to compute reliably
        
    # Standard thresholding: Find peaks above the 85th percentile of the current window
    arr_samples = np.array(samples)
    threshold = np.percentile(arr_samples, 85)
    
    peaks = []
    # Find local maximum indices that cross our threshold boundary
    for i in range(1, len(samples) - 1):
        if samples[i] > threshold and samples[i] > samples[i-1] and samples[i] > samples[i+1]:
            peaks.append(timestamps[i])
            
    # Calculate intervals between detected peaks to deduce Heart Rate
    if len(peaks) >= 2:
        # Prevent counting adjacent samples as separate beats (de-bounce interval of 0.3s)
        filtered_peaks = [peaks[0]]
        for p in peaks[1:]:
            if p - filtered_peaks[-1] > 0.3:
                filtered_peaks.append(p)
                
        if len(filtered_peaks) >= 2:
            intervals = np.diff(filtered_peaks)
            avg_interval = np.mean(intervals)
            bpm = int(60.0 / avg_interval)
            
    return bpm

async def read_serial_and_broadcast():
    """Reads incoming voltage from the ESP32 and broadcasts to the Web UI"""
    print(f"Connecting to ESP32 on {SERIAL_PORT}...")
    try:
        # Open serial port non-blocking compatible with asyncio loop execution
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
    except Exception as e:
        print(f"\nError opening serial port: {e}")
        print("Make sure your browser tabs connecting directly to the port (like ESPHome) are closed!")
        return

    print("\nSuccessfully connected to hardware! Waiting for dashboard clients...")
    
    while True:
        if ser.in_waiting > 0:
            try:
                line = ser.readline().decode('utf-8').strip()
                if line:
                    voltage = float(line)
                    current_bpm = estimate_bpm(voltage)
                    
                    # Package data packet for transmission
                    payload = json.dumps({
                        "voltage": voltage,
                        "bpm": current_bpm
                    })
                    
                    # Broadcast packet to all open browser windows running your dashboard
                    if CONNECTED_CLIENTS:
                        await asyncio.gather(*[client.send(payload) for client in CONNECTED_CLIENTS])
                        
            except ValueError:
                pass # Skip broken or incomplete serial lines cleanly
            except Exception as e:
                print(f"Streaming error: {e}")
                
        await asyncio.sleep(0.005) # Tiny sleep interval to maintain processor performance

async def register_client(websocket):
    """Tracks browser dashboard instances connecting to our script"""
    CONNECTED_CLIENTS.add(websocket)
    print(f"Dashboard view connected! Total views: {len(CONNECTED_CLIENTS)}")
    try:
        await websocket.wait_closed()
    finally:
        CONNECTED_CLIENTS.remove(websocket)
        print(f"Dashboard view disconnected. Total views: {len(CONNECTED_CLIENTS)}")

async def main():
    # Spin up WebSocket server listening locally on port 8765
    server = await websockets.serve(register_client, "localhost", 8765)
    
    # Run serial processor task concurrently alongside our server tasks
    await read_serial_and_broadcast()
    await server.wait_closed()

if __name__ == "__main__":
    try:
        import websockets
    except ImportError:
        print("Missing 'websockets' library. Please run: pip install websockets")
        exit()
        
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nServer shutting down gracefully.")