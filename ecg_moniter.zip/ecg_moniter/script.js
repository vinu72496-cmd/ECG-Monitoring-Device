// --- STATE DATA STORES ---
const MAX_DATA_POINTS = 300; 
let isStreamPaused = false;
let ecgChart = null;
let socket = null;

// Wrap everything inside a safe DOM load event listener to prevent initialization errors
document.addEventListener("DOMContentLoaded", () => {
    // 1. DOM Hooks References with safety verification
    const bpmDisplay = document.getElementById('bpmDisplay');
    const bpmStatusBadge = document.getElementById('bpmStatusBadge');
    const signalStability = document.getElementById('signalStability');
    const connectionStatus = document.getElementById('connectionStatus');
    const eventLogs = document.getElementById('eventLogs');
    const pauseBtn = document.getElementById('pauseBtn');
    const clearLogBtn = document.getElementById('clearLogBtn');

    // Helper Logging Engine
    function appendLog(message, isAlert = false) {
        if (!eventLogs) return;
        const timestamp = new Date().toLocaleTimeString();
        const entry = document.createElement('div');
        entry.className = isAlert ? 'log-entry alert-msg' : 'log-entry';
        entry.innerText = [${timestamp}] ${message};
        eventLogs.appendChild(entry);
        eventLogs.scrollTop = eventLogs.scrollHeight;
    }

    // 2. Chart Initialization Engine with canvas presence check
    const canvasElement = document.getElementById('ecgChart');
    if (canvasElement) {
        const ctx = canvasElement.getContext('2d');
        ecgChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({length: MAX_DATA_POINTS}, (_, i) => i),
                datasets: [{
                    label: 'ECG Signal Input Feed (Volts)',
                    data: Array(MAX_DATA_POINTS).fill(null),
                    borderColor: '#10b981',
                    borderWidth: 2,
                    pointRadius: 0,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false, // Performance speed optimization
                scales: {
                    y: { min: 0, max: 3.3, title: { display: true, text: 'Potential Difference (V)' } },
                    x: { display: false }
                }
            }
        });
    } else {
        console.error("Critical Error: 'ecgChart' canvas element not found in HTML.");
    }

    // Dynamic UI Modifiers
    function updateMetricsDisplay(voltage, bpm) {
        if (signalStability) {
            signalStability.innerHTML = ${voltage.toFixed(2)} <span class="unit">V</span>;
        }
        
        if (isStreamPaused || !ecgChart) return;

        // Real-time signal graphing
        ecgChart.data.datasets[0].data.push(voltage);
        if (ecgChart.data.datasets[0].data.length > MAX_DATA_POINTS) {
            ecgChart.data.datasets[0].data.shift();
        }
        ecgChart.update();

        // Heart Rate evaluation bounds
        if (bpmDisplay && bpmStatusBadge && bpm !== undefined && bpm > 0) {
            bpmDisplay.innerHTML = ${bpm} <span class="unit">BPM</span>;
            
            if (bpm < 60 || bpm > 100) {
                bpmStatusBadge.innerText = bpm < 60 ? "Bradycardia Alert" : "Tachycardia Alert";
                bpmStatusBadge.className = "status-pill status-red";
            } else {
                bpmStatusBadge.innerText = "Normal Sinus Rhythm";
                bpmStatusBadge.className = "status-pill status-green";
            }
        }
    }

    // User Interfaces Click Handlers
    if (pauseBtn) {
        pauseBtn.addEventListener('click', () => {
            isStreamPaused = !isStreamPaused;
            pauseBtn.innerText = isStreamPaused ? "Resume Stream" : "Freeze Stream";
            appendLog(isStreamPaused ? "Display waveform frozen by operator." : "Live telemetry feed resumed.");
        });
    }

    if (clearLogBtn) {
        clearLogBtn.addEventListener('click', () => {
            if (eventLogs) eventLogs.innerHTML = <div class="log-entry system-msg">Logs cleared by operator.</div>;
        });
    }

    // 3. Connect Socket Function
    function connectWebSocket() {
        appendLog("Attempting connection to local WebSocket server...");
        socket = new WebSocket('ws://localhost:8765');

        socket.onopen = () => {
            if (connectionStatus) {
                connectionStatus.innerText = "Hardware Online (COM3)";
                connectionStatus.className = "status-badge state-connected";
            }
            appendLog("Secure channel socket connected. Streaming raw ADC packets.");
        };

        socket.onclose = () => {
            if (connectionStatus) {
                connectionStatus.innerText = "Hardware Disconnected";
                connectionStatus.className = "status-badge state-disconnected";
            }
            appendLog("Link lost. Retrying to connect in 3 seconds...", true);
            setTimeout(connectWebSocket, 3000); // Auto-reconnect safety loop
        };

        socket.onerror = () => {
            // Silence underlying network handshake connection exceptions cleanly
        };

        socket.onmessage = (event) => {
            try {
                const payload = JSON.parse(event.data);
                if (payload.voltage !== undefined) {
                    updateMetricsDisplay(parseFloat(payload.voltage), parseInt(payload.bpm));
                }
            } catch (err) {
                // Skip structural parsing noise anomalies cleanly
            }
        };
    }

    // Fire network initialization link
    connectWebSocket();
});