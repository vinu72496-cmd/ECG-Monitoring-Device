import machine
import time

# --- HARDWARE INITIALIZATION ---
# Initialize the Analog-to-Digital Converter (ADC) on GPIO34 (AD8232 OUT pin)
adc = machine.ADC(machine.Pin(34))

# Configure ADC attenuation for full range measurement (0.0V to 3.3V)
adc.atten(machine.ADC.ATTN_11DB)

# Setup UART0 for USB Serial Communication (Default link to your PC)
uart = machine.UART(0, baudrate=115200)

# Configure Leads-Off Detection pins 
lo_plus = machine.Pin(35, machine.Pin.IN)
lo_minus = machine.Pin(32, machine.Pin.IN) 

print("ESP32 ECG Streaming Initialized... Sampling at 100Hz.")

# --- MAIN STREAMING LOOP ---
while True:
    # Check if electrodes are correctly attached to the body
    if lo_plus.value() == 1 or lo_minus.value() == 1:
        # Stream a safe flat line value if pads are disconnected
        voltage_str = "0.00\n"
        uart.write(voltage_str.encode())
        
    else:
        # Read raw 16-bit digital integer (0 to 65535)
        raw_value = adc.read_u16()
        
        # Convert digital value back into an absolute Voltage value
        voltage = (raw_value / 65535.0) * 3.3
        
        # Format string and send over USB Serial cable
        voltage_str = "{:.2f}\n".format(voltage)
        uart.write(voltage_str.encode())
    
    # Maintain steady 100 Hz Sampling Frequency (10ms intervals)
    time.sleep(0.01)

